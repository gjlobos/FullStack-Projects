package com.gjlobos.notesspabackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotesSpaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotesSpaBackendApplication.class, args);
	}

}
