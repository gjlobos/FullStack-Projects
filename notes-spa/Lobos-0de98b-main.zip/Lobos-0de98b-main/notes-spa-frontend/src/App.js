import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import ActiveNotesPage from './components/ActiveNotesPage';
import ArchivedNotesPage from './components/ArchivedNotesPage';

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/" exact component={ActiveNotesPage} />
        <Route path="/archived" component={ArchivedNotesPage} />
      </Switch>
    </Router>
  );
}

export default App;
